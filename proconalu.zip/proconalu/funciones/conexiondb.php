<?php
$host = "localhost";
$usuario ="root";
$clave="";
$bd ="proconalu";

$conexion = mysqli_connect($host,$usuario,$clave,$bd);


?>